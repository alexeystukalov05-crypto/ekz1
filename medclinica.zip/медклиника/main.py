import sys
import os
from typing import Any, Iterable, List, Sequence
import pymysql
import pymysql.cursors
from PyQt6 import QtCore, QtWidgets, uic
from PyQt6.QtWidgets import (
    QMessageBox, QTableWidget, QTableWidgetItem, QDialog,
    QVBoxLayout, QLineEdit, QLabel, QDialogButtonBox,
    QInputDialog, QTextEdit, QDateEdit, QTimeEdit
)

# =========================
# КОНФИГУРАЦИЯ БД
# =========================
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "12345",  # <--- УКАЖИТЕ ВАШ ПАРОЛЬ ОТ MYSQL
    "database": "medical_clinic",
    "charset": "utf8mb4",
}

def db_connect(dict_cursor: bool = False):
    if dict_cursor:
        return pymysql.connect(**DB_CONFIG, cursorclass=pymysql.cursors.DictCursor)
    return pymysql.connect(**DB_CONFIG)

def fill_table(table: QTableWidget, headers: List[str], rows: Iterable[Sequence[Any]]) -> None:
    """Вспомогательная функция для заполнения таблиц"""
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setRowCount(0)
    for i, row in enumerate(rows):
        table.insertRow(i)
        for j, val in enumerate(row):
            table.setItem(i, j, QTableWidgetItem("" if val is None else str(val)))
    table.resizeColumnsToContents()

# =========================
# ОКНО ВХОДА
# =========================
class LoginWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        if not os.path.exists("login.ui"):
            QMessageBox.critical(self, "Ошибка", "Файл login.ui не найден!")
            sys.exit(1)
            
        uic.loadUi("login.ui", self)
        self.btnLogin.clicked.connect(self.process_login)
        self.labelError.setText("")

    def process_login(self):
        login = self.inputLogin.text().strip()
        password = self.inputPassword.text().strip()

        if not login or not password:
            self.labelError.setText("Введите логин и пароль")
            return

        try:
            conn = db_connect(dict_cursor=True)
            cur = conn.cursor()

            # 1. Проверяем врачей (doctors)
            cur.execute("SELECT * FROM doctors WHERE login=%s AND password=%s", (login, password))
            doc = cur.fetchone()
            
            if doc:
                spec = (doc.get("specialization") or "").lower()
                conn.close()
                # Если специализация содержит "главврач", открываем окно директора
                if "главврач" in spec:
                    self.open_director(doc)
                else:
                    self.open_admin(doc)
                return

            # 2. Проверяем пациентов (patients) - логин это email
            cur.execute("SELECT * FROM patients WHERE email=%s AND password=%s", (login, password))
            pat = cur.fetchone()
            conn.close()

            if pat:
                self.open_patient(pat)
                return

            self.labelError.setText("Неверный логин или пароль")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка подключения", f"Ошибка: {e}")

    def open_admin(self, doc_row: dict):
        self.win = AdminWindow(doc_row)
        self.win.show()
        self.close()

    def open_director(self, doc_row: dict):
        self.win = DirectorWindow(doc_row)
        self.win.show()
        self.close()

    def open_patient(self, pat_row: dict):
        self.win = PatientWindow(pat_row)
        self.win.show()
        self.close()

# =========================
# ОКНО ГЛАВВРАЧА (Director)
# =========================
class DirectorWindow(QtWidgets.QMainWindow):
    def __init__(self, doc: dict):
        super().__init__()
        uic.loadUi("director.ui", self)
        self.doc = doc

        # Установка дат по умолчанию
        self.dateStart.setDate(QtCore.QDate.currentDate().addDays(-30))
        self.dateEnd.setDate(QtCore.QDate.currentDate())

        self.btnCalc.clicked.connect(self.calc_finance)
        self.btnEditPrice.clicked.connect(self.edit_price)
        self.btnLogout.clicked.connect(self.logout)

        self.load_services()

    def calc_finance(self):
        d1 = self.dateStart.date().toString("yyyy-MM-dd")
        d2 = self.dateEnd.date().toString("yyyy-MM-dd")

        try:
            conn = db_connect()
            cur = conn.cursor()
            # Считаем сумму платежей со статусом "Оплачен"
            cur.execute(
                """
                SELECT SUM(amount), COUNT(*) 
                FROM payments 
                WHERE payment_status='Оплачен' AND payment_date BETWEEN %s AND %s
                """,
                (d1, d2),
            )
            total, cnt = cur.fetchone()
            conn.close()

            total = total or 0
            cnt = cnt or 0
            avg = round(total / cnt, 2) if cnt > 0 else 0

            self.labelResult.setText(
                f"Период: {d1} — {d2}\n"
                f"Выручка: {total} руб.\n"
                f"Транзакций: {cnt}\n"
                f"Средний чек: {avg} руб."
            )
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def load_services(self):
        try:
            conn = db_connect()
            cur = conn.cursor()
            cur.execute(
                "SELECT id_service, service_name, service_category, price_oms, price_dms, price_paid, duration_minutes FROM service_pricelist"
            )
            fill_table(self.tableServices, 
                       ["ID", "Услуга", "Категория", "Цена ОМС", "Цена ДМС", "Цена Платная", "Мин."], 
                       cur.fetchall())
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def edit_price(self):
        row = self.tableServices.currentRow()
        if row == -1:
            QMessageBox.information(self, "Инфо", "Выберите услугу в таблице")
            return

        sid = self.tableServices.item(row, 0).text()
        curr_val = self.tableServices.item(row, 5).text() # price_paid column
        try:
            curr_float = float(curr_val)
        except:
            curr_float = 0.0

        val, ok = QInputDialog.getDouble(self, "Цена", "Новая платная цена:", curr_float, 0, 100000, 2)
        if ok:
            try:
                conn = db_connect()
                cur = conn.cursor()
                cur.execute("UPDATE service_pricelist SET price_paid=%s WHERE id_service=%s", (val, sid))
                conn.commit()
                conn.close()
                self.load_services()
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))

    def logout(self):
        self.win = LoginWindow()
        self.win.show()
        self.close()

# =========================
# ОКНО ВРАЧА / РЕГИСТРАТУРЫ (Admin)
# =========================
class AdminWindow(QtWidgets.QMainWindow):
    def __init__(self, doc: dict):
        super().__init__()
        uic.loadUi("admin.ui", self)
        self.doc = doc
        self.labelUser.setText(f"Сотрудник: {doc['fio']} ({doc['specialization']})")

        self.btnFilter.clicked.connect(self.load_appointments)
        self.btnReset.clicked.connect(lambda: (self.comboStatus.setCurrentIndex(0), self.load_appointments()))
        self.btnAddApp.clicked.connect(self.add_appointment)
        self.btnUpdateStatus.clicked.connect(self.update_status)
        self.btnAddRecord.clicked.connect(self.add_medical_record)
        self.btnLogout.clicked.connect(self.logout)

        self.load_appointments()
        self.load_patients()
        self.load_doctors()

    def get_selected_id(self, table):
        row = table.currentRow()
        if row == -1: return None
        try: return int(table.item(row, 0).text())
        except: return None

    def load_appointments(self):
        status = self.comboStatus.currentText()
        try:
            conn = db_connect()
            cur = conn.cursor()
            sql = """
                SELECT 
                    a.id_appointment, p.fio, d.fio, a.appointment_date, 
                    a.appointment_time, a.appointment_type, a.status, a.price
                FROM appointments a
                JOIN patients p ON a.id_patient = p.id_patient
                JOIN doctors d ON a.id_doctor = d.id_doctor
            """
            params = []
            if status != "Все":
                sql += " WHERE a.status=%s"
                params.append(status)
            sql += " ORDER BY a.appointment_date DESC, a.appointment_time DESC"
            
            cur.execute(sql, params)
            fill_table(self.tableAppointments, 
                       ["ID", "Пациент", "Врач", "Дата", "Время", "Тип", "Статус", "Цена"], 
                       cur.fetchall())
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def load_patients(self):
        try:
            conn = db_connect()
            cur = conn.cursor()
            cur.execute("SELECT id_patient, fio, birth_date, phone, insurance_type, insurance_policy_number FROM patients")
            fill_table(self.tablePatients, ["ID", "ФИО", "Д.Р.", "Телефон", "Тип", "Полис"], cur.fetchall())
            conn.close()
        except Exception as e:
            print(e)

    def load_doctors(self):
        try:
            conn = db_connect()
            cur = conn.cursor()
            cur.execute("SELECT id_doctor, fio, specialization, office_number, phone FROM doctors")
            fill_table(self.tableDoctors, ["ID", "ФИО", "Спец.", "Кабинет", "Телефон"], cur.fetchall())
            conn.close()
        except Exception as e:
            print(e)

    def add_appointment(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Запись пациента")
        layout = QVBoxLayout()

        inp_pid = QLineEdit(); inp_pid.setPlaceholderText("ID Пациента (из вкладки Пациенты)")
        inp_did = QLineEdit(); inp_did.setPlaceholderText("ID Врача (из вкладки Врачи)")
        inp_date = QDateEdit(); inp_date.setDate(QtCore.QDate.currentDate())
        inp_time = QTimeEdit(); inp_time.setTime(QtCore.QTime.currentTime())
        
        layout.addWidget(QLabel("ID Пациента:")); layout.addWidget(inp_pid)
        layout.addWidget(QLabel("ID Врача:")); layout.addWidget(inp_did)
        layout.addWidget(QLabel("Дата:")); layout.addWidget(inp_date)
        layout.addWidget(QLabel("Время:")); layout.addWidget(inp_time)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        layout.addWidget(btns); dlg.setLayout(layout)

        if dlg.exec():
            try:
                pid = int(inp_pid.text())
                did = int(inp_did.text())
                dt = inp_date.date().toString("yyyy-MM-dd")
                tm = inp_time.time().toString("HH:mm:ss")
                
                conn = db_connect()
                cur = conn.cursor()
                cur.execute(
                    """INSERT INTO appointments (id_patient, id_doctor, appointment_date, appointment_time, appointment_type, status, price) 
                       VALUES (%s, %s, %s, %s, 'Первичный', 'Запланирован', 1500.00)""",
                    (pid, did, dt, tm)
                )
                conn.commit(); conn.close()
                self.load_appointments()
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Проверьте ID: {e}")

    def update_status(self):
        aid = self.get_selected_id(self.tableAppointments)
        if not aid: 
            QMessageBox.information(self, "Инфо", "Выберите запись в таблице")
            return

        statuses = ["Запланирован", "На приёме", "Завершён", "Отменён", "Не явился"]
        new_stat, ok = QInputDialog.getItem(self, "Статус", "Новый статус:", statuses, 0, False)
        if ok:
            try:
                conn = db_connect()
                cur = conn.cursor()
                cur.execute("UPDATE appointments SET status=%s WHERE id_appointment=%s", (new_stat, aid))
                conn.commit(); conn.close()
                self.load_appointments()
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))

    def add_medical_record(self):
        aid = self.get_selected_id(self.tableAppointments)
        if not aid:
            QMessageBox.information(self, "Инфо", "Выберите завершенный прием для описания диагноза")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle("Добавить диагноз")
        layout = QVBoxLayout()
        
        inp_complaints = QTextEdit(); inp_complaints.setPlaceholderText("Жалобы")
        inp_exam = QTextEdit(); inp_exam.setPlaceholderText("Осмотр")
        inp_mkb = QLineEdit(); inp_mkb.setPlaceholderText("Код МКБ-10 (J06.9)")
        inp_diag = QLineEdit(); inp_diag.setPlaceholderText("Описание диагноза")
        inp_treat = QTextEdit(); inp_treat.setPlaceholderText("Лечение")

        layout.addWidget(QLabel("Жалобы:")); layout.addWidget(inp_complaints)
        layout.addWidget(QLabel("Осмотр:")); layout.addWidget(inp_exam)
        layout.addWidget(QLabel("Код МКБ:")); layout.addWidget(inp_mkb)
        layout.addWidget(QLabel("Диагноз:")); layout.addWidget(inp_diag)
        layout.addWidget(QLabel("Лечение:")); layout.addWidget(inp_treat)
        
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        layout.addWidget(btns); dlg.setLayout(layout)

        if dlg.exec():
            try:
                conn = db_connect()
                cur = conn.cursor()
                # Получаем данные из приема
                cur.execute("SELECT id_patient, id_doctor, appointment_date FROM appointments WHERE id_appointment=%s", (aid,))
                res = cur.fetchone()
                if not res: return
                pid, did, adate = res

                cur.execute("""
                    INSERT INTO medical_records 
                    (id_appointment, id_patient, id_doctor, record_date, complaints, examination, diagnosis_icd10, diagnosis_description, treatment_plan)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (aid, pid, did, adate, inp_complaints.toPlainText(), inp_exam.toPlainText(), 
                      inp_mkb.text(), inp_diag.text(), inp_treat.toPlainText()))
                
                # Закрываем прием
                cur.execute("UPDATE appointments SET status='Завершён' WHERE id_appointment=%s", (aid,))
                conn.commit(); conn.close()
                self.load_appointments()
                QMessageBox.information(self, "Успех", "Запись добавлена в медкарту")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))

    def logout(self):
        self.win = LoginWindow()
        self.win.show()
        self.close()

# =========================
# ОКНО ПАЦИЕНТА (Patient)
# =========================
class PatientWindow(QtWidgets.QMainWindow):
    def __init__(self, pat: dict):
        super().__init__()
        uic.loadUi("patient.ui", self)
        self.pat = pat
        self.labelWelcome.setText(f"Пациент: {pat['fio']}")
        
        self.btnNewApp.clicked.connect(self.request_appointment)
        self.btnLogout.clicked.connect(self.logout)
        self.load_history()

    def load_history(self):
        try:
            conn = db_connect()
            cur = conn.cursor()
            cur.execute("""
                SELECT 
                    a.appointment_date, a.appointment_time, d.specialization, 
                    d.fio, a.status, mr.diagnosis_description
                FROM appointments a
                LEFT JOIN doctors d ON a.id_doctor = d.id_doctor
                LEFT JOIN medical_records mr ON mr.id_appointment = a.id_appointment
                WHERE a.id_patient = %s
                ORDER BY a.appointment_date DESC
            """, (self.pat['id_patient'],))
            fill_table(self.tableHistory, ["Дата", "Время", "Спец.", "Врач", "Статус", "Диагноз"], cur.fetchall())
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def request_appointment(self):
        text, ok = QInputDialog.getText(self, "Запись", "К какому врачу (специализация или ID)?")
        if not ok or not text: return
        
        try:
            # Для простоты записываем к врачу ID=1, если введен текст
            target_doctor_id = 1 
            conn = db_connect()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO appointments (id_patient, id_doctor, appointment_date, appointment_time, appointment_type, status, price, notes)
                VALUES (%s, %s, CURDATE() + INTERVAL 1 DAY, '09:00:00', 'Первичный', 'Запланирован', 0, %s)
            """, (self.pat['id_patient'], target_doctor_id, f"Запрос: {text}"))
            conn.commit(); conn.close()
            QMessageBox.information(self, "Успех", "Заявка создана (на завтра 09:00)")
            self.load_history()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def logout(self):
        self.win = LoginWindow()
        self.win.show()
        self.close()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    w = LoginWindow()
    w.show()
    sys.exit(app.exec())